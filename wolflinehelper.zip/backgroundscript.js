webRequest.onBeforeRequest = function(eventData){
	console.log("onBeforeRequest");
}